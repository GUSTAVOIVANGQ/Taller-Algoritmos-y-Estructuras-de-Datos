#include <stdio.h>
#include <stdlib.h>


 void main (){

 
  int a [6};


 }
