#include <stdio.h>
#include <stdlib.h>
#include "pila.c"

int main(int argc, char *argv[]) {

    


	return 0;
}

